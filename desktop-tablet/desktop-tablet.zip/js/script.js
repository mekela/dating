$(document).ready(function () {
  $('[data-toggle="tooltip"]').tooltip();
  $('#upload-photo1').modal('show');
});